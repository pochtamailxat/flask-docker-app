
# Flask Docker App

Простое Flask-приложение для DevOps-практики.

## Запуск локально:

```bash
docker-compose up --build
```

Открой в браузере: http://localhost:5000
